<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<header class="site-header" style="background:linear-gradient(90deg,#1A73E8,#1A73E8); color:white; padding:12px 0;">

  <!-- TOP HEADER WRAPPER -->
  <div class="wrap" style="display:flex;align-items:center;justify-content:space-between;">

      <!-- LEFT SIDE : LOGO -->
      <div class="site-title" style="font-weight:800;font-size:22px;">
        <a href="<?php echo esc_url( home_url('/') ); ?>" 
           style="color:white; font-size:30px; text-decoration:none;">
           📚 Result Time
        </a>
      </div>

      <!-- RIGHT SIDE : HAMBURGER MENU BUTTON -->
      <div class="menu-toggle" onclick="openMenu()">
          <div class="menu-icon">
             <div></div>
          </div>
      </div>

  </div>

  <!-- RIGHT-SIDE SLIDE MENU -->
  <div id="sideMenu" class="side-menu">

      <div class="close-btn" onclick="closeMenu()">✖</div>

      <?php
        wp_nav_menu( array(
            'theme_location' => 'primary',
            'container'      => false,
            'menu_class'     => 'side-menu-list',
            'items_wrap'     => '<ul class="side-menu-list">%3$s</ul>'
        ));
      ?>
  </div>

  <!-- HERO SECTION -->
  <div class="wrap hero" style="text-align:center;padding:16px 0 12px;">
     <h1 style="margin:0 0 6px;color:white;font-size:26px;">
        पढ़ाई में दिल लगाओ, रिजल्ट खुद मुस्कुराएगा!
     </h1>

     <div class="searchbox" style="display:flex;justify-content:center;gap:8px;">
        <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
          <input type="search" name="s" placeholder="Search..." 
                 style="width:70%;padding:10px;border-radius:6px;border:0;">
          <button type="submit" 
                 style="padding:10px 14px;border-radius:6px;background:#2b6ea1;color:white;border:0;cursor:pointer;">
            🔍
          </button>
        </form>
     </div>

  </div>

</header>

<!-- JS FOR SLIDE MENU -->
<script>
function openMenu() {
    document.getElementById("sideMenu").classList.add("open");
}
function closeMenu() {
    document.getElementById("sideMenu").classList.remove("open");
}
</script>

<?php /* Body continues */ ?>
