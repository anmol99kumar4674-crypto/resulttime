<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>PDF to Image Converter</h1>

<input type="file" id="pdfFile" accept="application/pdf">

<br><br>

<button onclick="convertPDF()">Convert to Image</button>

<div id="images"></div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js"></script>

<script>

async function convertPDF(){

let file=document.getElementById("pdfFile").files[0];

let fileReader=new FileReader();

fileReader.onload=async function(){

let typedarray=new Uint8Array(this.result);

let pdf=await pdfjsLib.getDocument(typedarray).promise;

let container=document.getElementById("images");

container.innerHTML="";

for(let i=1;i<=pdf.numPages;i++){

let page=await pdf.getPage(i);

let viewport=page.getViewport({scale:2});

let canvas=document.createElement("canvas");

let context=canvas.getContext("2d");

canvas.height=viewport.height;
canvas.width=viewport.width;

await page.render({
canvasContext:context,
viewport:viewport
}).promise;

let img=canvas.toDataURL("image/png");

let image=document.createElement("img");
image.src=img;
image.style.maxWidth="100%";

container.appendChild(image);

let link=document.createElement("a");
link.href=img;
link.download="page-"+i+".png";
link.innerText="Download Page "+i;

container.appendChild(link);
container.appendChild(document.createElement("br"));
container.appendChild(document.createElement("br"));

}

};

fileReader.readAsArrayBuffer(file);

}

</script>

<?php get_footer(); ?>