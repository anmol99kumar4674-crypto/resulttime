<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>Image Converter</h1>

<input type="file" id="upload" accept="image/*">

<br><br>

<select id="format">
<option value="image/jpeg">JPG</option>
<option value="image/png">PNG</option>
<option value="image/webp">WEBP</option>
</select>

<br><br>

<button onclick="convertImage()">Convert Image</button>

<br><br>

<img id="preview" style="max-width:100%">

<br><br>

<a id="download" style="display:none">Download Image</a>

</div>

<script>

function convertImage(){

let file=document.getElementById("upload").files[0];
let format=document.getElementById("format").value;

let reader=new FileReader();

reader.onload=function(e){

let img=new Image();

img.src=e.target.result;

img.onload=function(){

let canvas=document.createElement("canvas");
let ctx=canvas.getContext("2d");

canvas.width=img.width;
canvas.height=img.height;

ctx.drawImage(img,0,0);

let url=canvas.toDataURL(format);

document.getElementById("preview").src=url;

let link=document.getElementById("download");

link.href=url;
link.download="converted-image";
link.innerHTML="Download Image";
link.style.display="inline-block";

}

}

reader.readAsDataURL(file);

}

</script>

<?php get_footer(); ?>