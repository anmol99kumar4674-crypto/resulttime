<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>Reduce Image Size</h1>

<input type="file" id="upload" accept="image/*">

<br><br>

<label>Compression Level</label>

<input type="range" id="quality" min="0.1" max="1" step="0.1" value="0.7">

<br><br>

<button onclick="reduceImage()">Reduce Image</button>

<br><br>

<img id="preview" style="max-width:100%">

<br><br>

<a id="download" style="display:none">Download Image</a>

</div>

<script>

function reduceImage(){

let file=document.getElementById("upload").files[0];
let quality=document.getElementById("quality").value;

let reader=new FileReader();

reader.onload=function(e){

let img=new Image();

img.src=e.target.result;

img.onload=function(){

let canvas=document.createElement("canvas");
let ctx=canvas.getContext("2d");

canvas.width=img.width;
canvas.height=img.height;

ctx.drawImage(img,0,0);

let url=canvas.toDataURL("image/jpeg",quality);

document.getElementById("preview").src=url;

let link=document.getElementById("download");

link.href=url;
link.download="reduced-image.jpg";
link.innerHTML="Download Image";
link.style.display="inline-block";

}

}

reader.readAsDataURL(file);

}

</script>

<?php get_footer(); ?>