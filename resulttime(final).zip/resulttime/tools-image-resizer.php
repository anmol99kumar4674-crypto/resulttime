<?php get_header(); ?>

<style>

.resizer{
max-width:1000px;
margin:auto;
padding:40px 20px;
font-family:Arial;
}

.control-panel{
border:1px solid #ddd;
padding:20px;
background:#f7f7f7;
display:flex;
flex-wrap:wrap;
gap:20px;
align-items:center;
}

.box{
display:flex;
align-items:center;
gap:10px;
}

.box input[type=number]{
width:70px;
padding:6px;
}

.preview-area{
border:1px solid #ddd;
padding:20px;
margin-top:20px;
display:grid;
grid-template-columns:repeat(3,1fr);
gap:20px;
}

.image-card{
background:#fff;
padding:10px;
border-radius:8px;
box-shadow:0 2px 6px rgba(0,0,0,0.1);
text-align:center;
position:relative;
}

.image-card img{
width:100%;
border-radius:6px;
}

.remove{
position:absolute;
top:6px;
right:6px;
width:24px;
height:24px;
background:#fff;
border-radius:50%;
display:flex;
align-items:center;
justify-content:center;
cursor:pointer;
box-shadow:0 0 3px rgba(0,0,0,0.3);
}

.add-box{
width:200px;
height:200px;
border-radius:50%;
border:2px solid #ddd;
display:flex;
align-items:center;
justify-content:center;
cursor:pointer;
font-size:18px;
margin:auto;
}

.bottom-bar{
border:1px solid #ddd;
padding:15px;
margin-top:20px;
display:flex;
justify-content:space-between;
align-items:center;
}

.resize-btn{
background:#1e73be;
color:#fff;
border:none;
padding:12px 25px;
border-radius:6px;
cursor:pointer;
}

.select-btn{
padding:10px 20px;
border:1px solid #1e73be;
background:#fff;
border-radius:6px;
cursor:pointer;
}

</style>


<div class="resizer">

<div class="control-panel">

<div class="box">
Width
<input type="number" id="width" placeholder="Auto">
px
</div>

<div class="box">
Height
<input type="number" id="height" placeholder="Auto">
px
</div>

</div>


<div class="preview-area" id="previewArea">

<div class="add-box" onclick="fileInput.click()">
+ <br> Add Images
</div>

</div>


<div class="bottom-bar">

<button class="select-btn" onclick="fileInput.click()">Select Image</button>

<div>
<button onclick="clearImages()">🗑</button>
<button class="resize-btn" onclick="resizeImages()">Resize Image</button>
</div>

</div>

<input type="file" id="fileInput" multiple accept="image/*" style="display:none">

</div>



<script>

let images=[];
const fileInput=document.getElementById("fileInput");
const preview=document.getElementById("previewArea");

fileInput.addEventListener("change",function(e){

for(let file of e.target.files){

const reader=new FileReader();

reader.onload=function(event){

let img=new Image();
img.src=event.target.result;

images.push(img);

let card=document.createElement("div");
card.className="image-card";

card.innerHTML=`
<div class="remove">✖</div>
<img src="${event.target.result}">
<p>${Math.round(file.size/1024)} KB</p>
`;

card.querySelector(".remove").onclick=()=>{
card.remove();
images.splice(images.indexOf(img),1);
};

preview.prepend(card);

}

reader.readAsDataURL(file);

}

});


function resizeImages(){

let width=document.getElementById("width").value;
let height=document.getElementById("height").value;

preview.innerHTML="";

images.forEach(img=>{

let canvas=document.createElement("canvas");
let ctx=canvas.getContext("2d");

let w=width?width:img.width;
let h=height?height:img.height;

canvas.width=w;
canvas.height=h;

ctx.drawImage(img,0,0,w,h);

let data = canvas.toDataURL("image/png",1.0);

let card=document.createElement("div");
card.className="image-card";

card.innerHTML=`
<img src="${data}">
<br>
<a href="${data}" download="resized-image.jpg">
<button class="resize-btn">Download</button>
</a>
`;

preview.appendChild(card);

});

}


function clearImages(){

images=[];
preview.innerHTML="";

}

</script>


<?php get_footer(); ?>