<?php get_header(); ?>

<div style="max-width:900px;margin:auto;padding:20px;">
<h2><?php single_cat_title(); ?></h2>

<?php if(have_posts()): while(have_posts()): the_post(); ?>

<div style="padding:10px;border-bottom:1px solid #eee;">
•<a href="<?php the_permalink(); ?>" style="font-weight:600;color:#1A73E8;">
<?php the_title(); ?>
</a>
</div>

<?php endwhile; else: ?>

<p>No posts found</p>

<?php endif; ?>

</div>

<?php get_footer(); ?>