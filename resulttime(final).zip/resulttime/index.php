<?php get_header(); ?>
<main class="site-main">
  <div class="wrap">
    <div class="featured">
      <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:6px;">
    <?php
    $featured = new WP_Query( array('post_type'=>'post','posts_per_page'=>6,'post_status'=>'publish') );
    if ( $featured->have_posts() ) :
        $i = 1;
        $colors = array(
            '#e74c3c', // Red
            '#27ae60', // Green
            '#f39c12', // Orange
            '#2980b9', // Blue
            '#8e44ad', // Purple
            '#f1c40f'  // Yellow
        );
        while ( $featured->have_posts() ) : $featured->the_post();
            $color = $colors[($i - 1) % count($colors)];
        ?>
            <a href="<?php the_permalink(); ?>" style="text-decoration:none;">
                <div style="
                    background: <?php echo $color; ?>;
                    color: <?php echo ($color == '#f1c40f') ? '#000' : '#fff'; ?>;
                    border-radius: 12px;
                    padding: 8px;
                    font-weight: 600;
                    text-align: center;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                    font-size: 14px; /* ⬅️ छोटा font */
                    line-height: 1.3;
                    display: -webkit-box;
                    -webkit-line-clamp: 3; /* ⬅️ केवल 3 लाइन दिखे */
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    height: 2.2em; /* लगभग 3 लाइन */
                ">
                    <?php the_title(); ?>
                </div>
            </a>
        <?php 
            $i++;
        endwhile;
        wp_reset_postdata();
    endif;
    ?>
</div>
<style>
div[style*="background"] {
  transition: transform .3s ease, box-shadow .3s ease;
}
div[style*="background"]:hover {
  transform: scale(1.05);
  box-shadow: 0 6px 20px rgba(0,0,0,0.3);
}    
</style>

    </div>

<a href="<?php echo site_url('/category/latest-update'); ?>" class="rrb-banner-link">
    <div class="rrb-banner">
        
        <marquee class="alert-text" behavior="scroll" direction="left">
            🚨 Breaking: Your Exam Notification Released — Apply Soon! CLICK HERE
        </marquee>

        <div class="rrb-left">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/resulttime-logo.png">
        </div>

        <div class="rrb-content">
            <h2><span>Latest </span> Update</h2>
            <p>Notification(Click:-Bell Icon)</p>
        </div>

        <div class="rrb-right">
            <span class="notify-bell">🔔<span class="count">2</span></span>
        </div>
    </div>
</a>

    <!-- 3-column Latest Section -->
    <section class="home-sections" style="margin-top:36px;">
      <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:18px;">
        <!-- Result -->
        <div class="home-box" style="background:white; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08);">
          <div style="background:#1A73E8; color:white; padding:10px 12px; border-radius:8px 8px 0 0; font-weight:700;">Result</div>
          <div style="padding:12px;">
            <?php
              $result = new WP_Query(array('category_name'=>'result','posts_per_page'=>5,'post_type'=>'post'));
              if($result->have_posts()): while($result->have_posts()): $result->the_post(); ?>
                <div style="border-bottom:1px solid #eee; padding:8px 0;">
                  <a href="<?php the_permalink(); ?>" style="font-weight:600; color:#1A73E8;"><?php the_title(); ?></a>
                  
                </div>
              <?php endwhile; endif; wp_reset_postdata(); ?>
            <div style="text-align:right; margin-top:10px;">
              <a href="<?php echo site_url('/category/result'); ?>" style="color:#1A73E8; font-weight:600;">Read More →</a>
            </div>
          </div>
        </div>

        <!-- Admit Card -->
        <div class="home-box" style="background:white; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08);">
          <div style="background:#1A73E8; color:white; padding:10px 12px; border-radius:8px 8px 0 0; font-weight:700;">Admit Card</div>
          <div style="padding:12px;">
            <?php
              $admit = new WP_Query(array('category_name'=>'admit-card','posts_per_page'=>5,'post_type'=>'post'));
              if($admit->have_posts()): while($admit->have_posts()): $admit->the_post(); ?>
                <div style="border-bottom:1px solid #eee; padding:8px 0;">
                  <a href="<?php the_permalink(); ?>" style="font-weight:600; color:#1A73E8;"><?php the_title(); ?></a>
                  <div style="margin-top:4px;">
                    
                  </div>
                </div>
              <?php endwhile; endif; wp_reset_postdata(); ?>
            <div style="text-align:right; margin-top:10px;">
              <a href="<?php echo site_url('/category/admit-card'); ?>" style="color:#1A73E8; font-weight:600;">Read More →</a>
            </div>
          </div>
        </div>

        <!-- Latest Jobs -->
        <div class="home-box" style="background:white; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08);">
          <div style="background:#1A73E8; color:white; padding:10px 12px; border-radius:8px 8px 0 0; font-weight:700;">Latest Jobs</div>
          <div style="padding:12px;">
            <?php
              $jobs = new WP_Query(array('category_name'=>'jobs','posts_per_page'=>5,'post_type'=>'post'));
              if($jobs->have_posts()): while($jobs->have_posts()): $jobs->the_post(); ?>
                <div style="border-bottom:1px solid #eee; padding:8px 0;">
                  <a href="<?php the_permalink(); ?>" style="font-weight:600; color:#1A73E8;"><?php the_title(); ?></a>
                  
                </div>
              <?php endwhile; endif; wp_reset_postdata(); ?>
            <div style="text-align:right; margin-top:10px;">
              <a href="<?php echo site_url('/category/jobs'); ?>" style="color:#1A73E8; font-weight:600;">Read More →</a>
            </div>
          </div>
        </div>
      </div>
    </section>

<!-- Additional Home Sections -->
<section class="home-sections" style="margin-top:36px;">
  <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:18px;">
    <!-- answer-key -->
    <div class="home-box" style="background:white; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08);">
      <div style="background:#1A73E8; color:white; padding:10px 12px; border-radius:8px 8px 0 0; font-weight:700;">Answer Key</div>
      <div style="padding:12px;">
        <?php
          $answer = new WP_Query(array('category_name'=>'answer-key','posts_per_page'=>5,'post_type'=>'post'));
          if($answer->have_posts()): while($answer->have_posts()): $answer->the_post(); ?>
            <div style="border-bottom:1px solid #eee; padding:8px 0;">
              <a href="<?php the_permalink(); ?>" style="font-weight:600; color:#1A73E8;"><?php the_title(); ?></a>
              <div style="margin-top:4px;">
                <a href="<?php the_permalink(); ?>" style="display:inline-block; background:#1A73E8; color:white; padding:4px 10px; border-radius:6px; font-size:13px;">View</a>
              </div>
            </div>
          <?php endwhile; endif; wp_reset_postdata(); ?>
        <div style="text-align:right; margin-top:10px;">
          <a href="<?php echo site_url('/category/answer-key'); ?>" style="color:#1A73E8; font-weight:600;">Read More →</a>
        </div>
      </div>
    </div>

    <!-- Admission -->
    <div class="home-box" style="background:white; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08);">
      <div style="background:#1A73E8; color:white; padding:10px 12px; border-radius:8px 8px 0 0; font-weight:700;">Admission</div>
      <div style="padding:12px;">
        <?php
          $admission = new WP_Query(array('category_name'=>'admission','posts_per_page'=>5,'post_type'=>'post'));
          if($admission->have_posts()): while($admission->have_posts()): $admission->the_post(); ?>
            <div style="border-bottom:1px solid #eee; padding:8px 0;">
              <a href="<?php the_permalink(); ?>" style="font-weight:600; color:#1A73E8;"><?php the_title(); ?></a>
            </div>
          <?php endwhile; endif; wp_reset_postdata(); ?>
        <div style="text-align:right; margin-top:10px;">
          <a href="<?php echo site_url('/category/admission'); ?>" style="color:#1A73E8; font-weight:600;">Read More →</a>
        </div>
      </div>
    </div>

    <!-- Govt Scheme -->
    <div class="home-box" style="background:white; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08);">
      <div style="background:#1A73E8; color:white; padding:10px 12px; border-radius:8px 8px 0 0; font-weight:700;">Govt Scheme</div>
      <div style="padding:12px;">
        <?php
          $scheme = new WP_Query(array('category_name'=>'govt-scheme','posts_per_page'=>5,'post_type'=>'post'));
          if($scheme->have_posts()): while($scheme->have_posts()): $scheme->the_post(); ?>
            <div style="border-bottom:1px solid #eee; padding:8px 0;">
              <a href="<?php the_permalink(); ?>" style="font-weight:600; color:#1A73E8;"><?php the_title(); ?></a>
              <div style="margin-top:4px;">
                <a href="<?php the_permalink(); ?>" style="display:inline-block; background:#1A73E8; color:white; padding:4px 10px; border-radius:6px; font-size:13px;">Open</a>
              </div>
            </div>
          <?php endwhile; endif; wp_reset_postdata(); ?>
        <div style="text-align:right; margin-top:10px;">
          <a href="<?php echo site_url('/category/govt-scheme'); ?>" style="color:#1A73E8; font-weight:600;">Read More →</a>
        </div>
      </div>
    </div>
  </div>
</section>



    <style>
    @media (max-width:900px){
      .home-sections>div{grid-template-columns:1fr!important;}
    }
    </style>

  </div>
</main>
<?php get_footer(); ?>
