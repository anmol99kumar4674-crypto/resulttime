<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>Name and Date on Photo</h1>

<input type="file" id="photo">

<br><br>

<input type="text" id="name" placeholder="Enter Name">

<br><br>

<input type="text" id="date" placeholder="Enter Date">

<br><br>

<button onclick="addText()">Generate Photo</button>

<br><br>

<canvas id="canvas" style="max-width:100%"></canvas>

<br><br>

<a id="download" style="display:none;">Download Photo</a>

</div>

<script>

function addText(){

let file=document.getElementById("photo").files[0];
let name=document.getElementById("name").value;
let date=document.getElementById("date").value;

let reader=new FileReader();

reader.onload=function(e){

let img=new Image();

img.src=e.target.result;

img.onload=function(){

let canvas=document.getElementById("canvas");
let ctx=canvas.getContext("2d");

canvas.width=img.width;
canvas.height=img.height;

ctx.drawImage(img,0,0);

ctx.font="30px Arial";
ctx.fillStyle="red";

ctx.fillText(name,20,img.height-60);
ctx.fillText(date,20,img.height-20);

let url=canvas.toDataURL("image/jpeg");

let link=document.getElementById("download");

link.href=url;
link.download="name-date-photo.jpg";
link.innerHTML="Download Photo";
link.style.display="inline-block";

}

}

reader.readAsDataURL(file);

}

</script>

<?php get_footer(); ?>