<?php
/* Template Name: Default Page */
get_header(); ?>

<div class="main-container" style="max-width:900px;margin:0 auto;padding:15px;">

    <?php
    if ( have_posts() ) :
        while ( have_posts() ) : the_post(); ?>

            <h1 class="page-title" style="margin:0 0 15px;">
                <?php the_title(); ?>
            </h1>

            <div class="page-content" style="margin-top:0;">
                <?php the_content(); ?>
            </div>

        <?php endwhile;
    else :
        echo "<p>Content not found.</p>";
    endif;
    ?>

</div>

<?php get_footer(); ?>
