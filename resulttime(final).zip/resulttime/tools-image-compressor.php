<?php get_header(); ?>

<div class="main-container">

<h1 style="text-align:center;">Compress Image to 100KB</h1>

<div style="text-align:center;margin-top:30px;">

<input type="file" id="upload">

<br><br>

Target Size (KB)
<input type="number" id="targetSize" value="100">

<br><br>

<button onclick="compressImage()">Compress Image</button>

<br><br>

<img id="preview" style="max-width:300px;display:block;margin:auto;">

<br>

<a id="downloadBtn" style="display:none;">Download Image</a>

</div>
</div>

<script>

function compressImage(){

var file=document.getElementById("upload").files[0];
var targetKB=document.getElementById("targetSize").value;

var reader=new FileReader();

reader.onload=function(event){

var img=new Image();

img.src=event.target.result;

img.onload=function(){

var canvas=document.createElement("canvas");
var ctx=canvas.getContext("2d");

canvas.width=img.width;
canvas.height=img.height;

ctx.drawImage(img,0,0);

var quality=0.9;

function tryCompress(){

canvas.toBlob(function(blob){

var sizeKB=blob.size/1024;

if(sizeKB>targetKB && quality>0.1){

quality-=0.05;
tryCompress();

}else{

var url=URL.createObjectURL(blob);

document.getElementById("preview").src=url;

var download=document.getElementById("downloadBtn");

download.href=url;
download.download="compressed.jpg";
download.style.display="inline-block";
download.innerHTML="Download Image";

}

},"image/jpeg",quality);

}

tryCompress();

}

}

reader.readAsDataURL(file);

}

</script>

<?php get_footer(); ?>