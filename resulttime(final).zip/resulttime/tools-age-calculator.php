<?php get_header(); ?>

<style>

.age-container{
max-width:800px;
margin:40px auto;
font-family:Segoe UI;
}

.age-card{
background:#fff;
border-radius:10px;
box-shadow:0 4px 15px rgba(0,0,0,0.1);
overflow:hidden;
}

.age-header{
background:#2f6fbe;
color:#fff;
padding:15px;
font-size:20px;
font-weight:600;
text-align:center;
}

.age-body{
padding:25px;
}

.age-row{
margin-bottom:15px;
}

.age-row label{
display:block;
font-weight:600;
margin-bottom:5px;
}

.age-row input{
width:100%;
padding:10px;
border:1px solid #ccc;
border-radius:5px;
}

.age-btn{
background:#4b7d2a;
color:#fff;
border:none;
padding:12px 25px;
font-size:16px;
border-radius:5px;
cursor:pointer;
}

.age-btn:hover{
background:#3f6824;
}

.result-box{
margin-top:20px;
background:#f8f8f8;
padding:20px;
border-left:4px solid #4b7d2a;
}

</style>


<div class="age-container">

<div class="age-card">

<div class="age-header">
Age Calculator
</div>

<div class="age-body">

<div class="age-row">
<label>Date of Birth</label>
<input type="date" id="dob">
</div>

<div class="age-row">
<label>Age at the Date of</label>
<input type="date" id="today">
</div>

<button class="age-btn" onclick="calculateAge()">
Calculate
</button>

<div id="result"></div>

</div>

</div>

</div>


<script>

function calculateAge(){

let dob=new Date(document.getElementById("dob").value);
let today=new Date(document.getElementById("today").value);

if(!dob || !today){

alert("Select both dates");
return;

}

let diff=today-dob;

let seconds=Math.floor(diff/1000);
let minutes=Math.floor(seconds/60);
let hours=Math.floor(minutes/60);
let days=Math.floor(hours/24);
let weeks=Math.floor(days/7);
let months=Math.floor(days/30);
let years=Math.floor(days/365);

document.getElementById("result").innerHTML=`

<div class="result-box">

<b>Age:</b><br><br>

${years} years ${months%12} months ${days%30} days<br><br>

or ${months} months ${days%30} days<br><br>

or ${weeks} weeks ${days%7} days<br><br>

or ${days} days<br><br>

or ${hours.toLocaleString()} hours<br><br>

or ${minutes.toLocaleString()} minutes<br><br>

or ${seconds.toLocaleString()} seconds

</div>

`;

}

</script>

<?php get_footer(); ?>