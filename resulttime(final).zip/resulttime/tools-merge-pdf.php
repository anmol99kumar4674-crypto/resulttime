<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>Merge PDF</h1>

<input type="file" id="pdfFiles" multiple accept="application/pdf">

<br><br>

<button onclick="mergePDF()">Merge PDF</button>

<br><br>

<a id="downloadPDF" style="display:none;">Download Merged PDF</a>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>

<script>

async function mergePDF(){

let files=document.getElementById("pdfFiles").files;

const mergedPdf = await PDFLib.PDFDocument.create();

for(let i=0;i<files.length;i++){

let file=files[i];

let arrayBuffer=await file.arrayBuffer();

let pdf=await PDFLib.PDFDocument.load(arrayBuffer);

let copiedPages=await mergedPdf.copyPages(pdf,pdf.getPageIndices());

copiedPages.forEach((page)=>mergedPdf.addPage(page));

}

let mergedBytes=await mergedPdf.save();

let blob=new Blob([mergedBytes],{type:"application/pdf"});

let url=URL.createObjectURL(blob);

let link=document.getElementById("downloadPDF");

link.href=url;
link.download="merged.pdf";
link.innerHTML="Download Merged PDF";
link.style.display="inline-block";

}

</script>

<?php get_footer(); ?>