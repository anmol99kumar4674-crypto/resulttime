<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>Crop Image Tool</h1>

<input type="file" id="upload" accept="image/*">

<br><br>

<canvas id="canvas" style="max-width:100%;border:1px solid #ccc"></canvas>

<br><br>

<label>X:</label>
<input type="number" id="x" value="0">

<label>Y:</label>
<input type="number" id="y" value="0">

<br><br>

<label>Width:</label>
<input type="number" id="w" value="200">

<label>Height:</label>
<input type="number" id="h" value="200">

<br><br>

<button onclick="cropImage()">Crop Image</button>

<br><br>

<a id="download" style="display:none">Download Cropped Image</a>

</div>

<script>

let img=new Image();

document.getElementById("upload").onchange=function(e){

let reader=new FileReader();

reader.onload=function(event){

img.src=event.target.result;

img.onload=function(){

let canvas=document.getElementById("canvas");
let ctx=canvas.getContext("2d");

canvas.width=img.width;
canvas.height=img.height;

ctx.drawImage(img,0,0);

}

}

reader.readAsDataURL(e.target.files[0]);

}

function cropImage(){

let x=document.getElementById("x").value;
let y=document.getElementById("y").value;
let w=document.getElementById("w").value;
let h=document.getElementById("h").value;

let canvas=document.createElement("canvas");
let ctx=canvas.getContext("2d");

canvas.width=w;
canvas.height=h;

ctx.drawImage(img,x,y,w,h,0,0,w,h);

let url=canvas.toDataURL("image/jpeg");

let link=document.getElementById("download");

link.href=url;
link.download="cropped.jpg";
link.innerHTML="Download Cropped Image";
link.style.display="inline-block";

}

</script>

<?php get_footer(); ?>