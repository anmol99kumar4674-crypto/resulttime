<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>Compress PDF</h1>

<input type="file" id="pdfFile" accept="application/pdf">

<br><br>

<button onclick="compressPDF()">Compress PDF</button>

<br><br>

<a id="downloadPDF" style="display:none;">Download Compressed PDF</a>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>

<script>

async function compressPDF(){

let file=document.getElementById("pdfFile").files[0];

let reader=new FileReader();

reader.onload=async function(){

let bytes=new Uint8Array(this.result);

let pdfDoc=await PDFLib.PDFDocument.load(bytes);

let compressedBytes=await pdfDoc.save({
useObjectStreams:true
});

let blob=new Blob([compressedBytes],{type:"application/pdf"});

let url=URL.createObjectURL(blob);

let link=document.getElementById("downloadPDF");

link.href=url;
link.download="compressed.pdf";
link.innerHTML="Download Compressed PDF";
link.style.display="inline-block";

}

reader.readAsArrayBuffer(file);

}

</script>

<?php get_footer(); ?>