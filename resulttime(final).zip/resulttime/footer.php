<div class="footer-tools">
  <a href="/tools" class="tool-btn">Compress Image</a>
  <a href="/tools" class="tool-btn">Image Resizer</a>
  <a href="/tools" class="tool-btn">Name and Date on Photo</a>
</div>

<footer class="site-footer">
  <div class="footer-container">

    <div class="footer-box">
      <h3>About Us</h3>
      <p>
        Hum job updates, admit card, result aur education related sahi aur fast information provide karte hain.
      </p>
    </div>

    <div class="footer-box">
      <h3>Important</h3>
      <ul>
        <li><a href="#">Privacy Policy</a></li>
        <li><a href="#">Disclaimer</a></li>
        <li><a href="#">Terms & Conditions</a></li>
      </ul>
    </div>

    <div class="footer-box">
      <h3>Follow Us</h3>
      <div class="social-icons">

        <a href="#" class="icon insta" title="Instagram">
          <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/instagram.svg" alt="">
        </a>

        <a href="#" class="icon yt" title="YouTube">
          <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/youtube.svg" alt="">
        </a>

        <a href="#" class="icon tg" title="Telegram">
          <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/telegram.svg" alt="">
        </a>

        <a href="https://whatsapp.com/channel/0029Vb7pdjsElagzw4x99z3e" class="icon wa" title="WhatsApp">
          <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/whatsapp.svg" alt="">
        </a>

      </div>
    </div>

  </div>

  <div class="footer-bottom">
    <p>© 2025 YourWebsite.com | All Rights Reserved.</p>
  </div>
</footer>
    
<script>
function openMenu() {
  document.getElementById("sideMenu").classList.add("open");
}
function closeMenu() {
  document.getElementById("sideMenu").classList.remove("open");
}
</script>
