<?php get_header(); ?>
<!-- ЁЯФ┤ Title Red Gradient Card (Responsive + No Bottom Radius) -->
<div style="
  background: linear-gradient(90deg, #e50914, #ff3b30);
  color:#fff;
  text-align:center;
  font-size:clamp(22px, 2.8vw, 28px); /* auto responsive font size */
  font-weight:700;
  border-top-left-radius:12px;
  border-top-right-radius:12px;
  border-bottom-left-radius:0; /* bottom radius рд╣рдЯрд╛рдпрд╛ рдЧрдпрд╛ */
  border-bottom-right-radius:0; /* bottom radius рд╣рдЯрд╛рдпрд╛ рдЧрдпрд╛ */
  padding:18px 15px;
  width:90%;
  max-width:900px;
  margin:20px auto 0 auto;
  box-shadow:0 4px 10px rgba(0,0,0,0.15);
  line-height:1.3;
">
  <?php the_title(); ?>
</div>



<!-- тЬЕ Job Post Layout by Rajnish Kumar -->
<style>
body.single {
  background: #f4f6f8;
  margin: 0;
  padding: 0;
  font-family: "Segoe UI", Arial, sans-serif;
}

.post-container {
  max-width: 1000px;
  margin: 2px auto;
  display: grid;
  grid-template-columns: 1fr;
  gap: 20px;
  padding: 0 12px;
}

.section {
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
  overflow: hidden;
  transition: all 0.3s ease;
}
.section:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 14px rgba(0,0,0,0.15);
}

.content h2 {
  background: #1e88ff;
  color: white;
  text-align: center;
  padding: 12px 10px;
  font-size: 22px;
  border-radius: 10px 10px 0 0;
  margin-top: 20px;
}

.content h2 + ul,
.content h2 + p {
  background: #fff;
  border-radius: 0 0 10px 10px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

.content p {
  margin: 0;
  line-height: 1.6;
}
.content h2:first-child {
  margin-top: 0;
}
.section .content {
  padding: 16px;
  font-size: 16px;
  color: #222;
}

@media (min-width: 900px) {
  .post-container {
    grid-template-columns: 1fr 1fr;
  }
  .section.wide {
    grid-column: span 2;
  }
}

.section .content a {
  color: #1e88ff;
  font-weight: 600;
  text-decoration: none;
}
.section .content a:hover {
  text-decoration: underline;
}

.job-table{width:100%;border-collapse:collapse;margin-top:10px}
.job-table td{border:1px solid #ddd;padding:8px;font-size:15px}
.section .content ul {
  padding-left: 18px !important;
  margin-left: 0;
}

.section .content ul li {
  padding: 8px 0;
  border-bottom: 1px solid #ddd;
}

.section .content ul li:last-child {
  border-bottom: none;
}
</style>

<div class="post-container">
<div class="section wide">
  <div class="content">
    <?php the_content(); ?>
  </div>
</div>
</div>
<?php get_footer(); ?>