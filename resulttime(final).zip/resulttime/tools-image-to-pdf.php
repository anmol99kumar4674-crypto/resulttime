<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>Image to PDF Converter</h1>

<input type="file" id="images" multiple accept="image/*">

<br><br>

<button onclick="createPDF()">Convert to PDF</button>

<br><br>

<a id="downloadPDF" style="display:none;">Download PDF</a>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

<script>

async function createPDF(){

const { jsPDF } = window.jspdf;

let files=document.getElementById("images").files;

let pdf=new jsPDF();

for(let i=0;i<files.length;i++){

let file=files[i];

let imgData=await fileToDataURL(file);

if(i>0) pdf.addPage();

pdf.addImage(imgData,'JPEG',10,10,180,160);

}

let pdfBlob=pdf.output('blob');

let url=URL.createObjectURL(pdfBlob);

let link=document.getElementById("downloadPDF");

link.href=url;
link.download="images.pdf";
link.innerHTML="Download PDF";
link.style.display="inline-block";

}

function fileToDataURL(file){

return new Promise((resolve)=>{

let reader=new FileReader();

reader.onload=function(e){

resolve(e.target.result);

}

reader.readAsDataURL(file);

});

}

</script>

<?php get_footer(); ?>