<?php
// Minimal functions.php to enqueue styles and support basic features.
function resulttime_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'resulttime' ),
    ) );
}
add_action( 'after_setup_theme', 'resulttime_setup' );

function resulttime_scripts() {

wp_enqueue_style(
'resulttime-style',
get_stylesheet_uri(),
array(),
time()
);

wp_enqueue_script(
'resulttime-js',
get_template_directory_uri().'/script.js',
array(),
time(),
true
);

}
add_action( 'wp_enqueue_scripts', 'resulttime_scripts' );

/* ---------------------------------------------
   Custom Meta Boxes for Job Post Layout
   (By Rajnish Kumar)
--------------------------------------------- */

function resulttime_add_custom_metabox() {
    add_meta_box(
        'job_post_details',
        '🧾 Job Post Details (Important Info)',
        'resulttime_metabox_callback',
        'post',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'resulttime_add_custom_metabox');

function resulttime_metabox_callback($post) {
    // Retrieve existing values
    $important_date = get_post_meta($post->ID, 'important_date', true);
    $application_fee = get_post_meta($post->ID, 'application_fee', true);
    $education = get_post_meta($post->ID, 'education', true);
    $links = get_post_meta($post->ID, 'links', true);
    ?>

    <style>
        .resulttime-meta label {
            font-weight: 600;
            color: #0059b3;
            display:block;
            margin:10px 0 4px;
        }
    </style>

    <div class="resulttime-meta">

        <!-- ⭐ WYSIWYG Editor: Important Date -->
        <label>🗓️ Important Date:</label>
        <?php
        wp_editor(
            $important_date,
            'important_date_editor',
            array(
                'textarea_name' => 'important_date',
                'media_buttons' => false,
                'teeny' => false,
                'textarea_rows' => 8,
            )
        );
        ?>

        <!-- ⭐ WYSIWYG Editor: Application Fee -->
        <label>💰 Application Fee:</label>
        <?php
        wp_editor(
            $application_fee,
            'application_fee_editor',
            array(
                'textarea_name' => 'application_fee',
                'media_buttons' => false,
                'teeny' => false,
                'textarea_rows' => 8,
            )
        );
        ?>

        <!-- ⭐ WYSIWYG Editor: Education -->
        <label>🎓 Educational Qualifications:</label>
        <?php
        wp_editor(
            $education,
            'education_editor',
            array(
                'textarea_name' => 'education',
                'media_buttons' => false,
                'teeny' => false,
                'textarea_rows' => 8,
            )
        );
        ?>

        <!-- ⭐ WYSIWYG Editor: Important Links -->
        <label>🔗 Important Links:</label>
        <?php
        wp_editor(
            $links,
            'links_editor',
            array(
                'textarea_name' => 'links',
                'media_buttons' => false,
                'teeny' => false,
                'textarea_rows' => 8,
            )
        );
        ?>

    </div>

    <?php
}

// Save data
function resulttime_save_meta_data($post_id) {
    if (array_key_exists('important_date', $_POST)) {
        update_post_meta($post_id, 'important_date', ($_POST['important_date']));
    }
    if (array_key_exists('application_fee', $_POST)) {
        update_post_meta($post_id, 'application_fee', ($_POST['application_fee']));
    }
    if (array_key_exists('education', $_POST)) {
        update_post_meta($post_id, 'education', ($_POST['education']));
    }
    if (array_key_exists('links', $_POST)) {
        update_post_meta($post_id, 'links', ($_POST['links']));
    }
}
add_action('save_post', 'resulttime_save_meta_data');

add_action('init', function(){

add_rewrite_rule(

'^age-calculator/?$',

'index.php?age_tool=1',

'top'

);

});

add_filter('query_vars', function($vars){

$vars[]='age_tool';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('age_tool')){

include get_template_directory().'/tools-age-calculator.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^image-resizer/?$',
'index.php?image_resizer=1',
'top'
);

});

add_filter('query_vars', function($vars){
$vars[]='image_resizer';
return $vars;
});

add_action('template_redirect', function(){

if(get_query_var('image_resizer')){

include get_template_directory().'/tools-image-resizer.php';
exit;

}

});

add_action('init', function(){

add_rewrite_rule(
'^image-to-pdf/?$',
'index.php?image_to_pdf=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='image_to_pdf';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('image_to_pdf')){

include get_template_directory().'/tools-image-to-pdf.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^compress-image/?$',
'index.php?compress_image=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='compress_image';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('compress_image')){

include get_template_directory().'/tools-image-compressor.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^pdf-to-image/?$',
'index.php?pdf_to_image=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='pdf_to_image';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('pdf_to_image')){

include get_template_directory().'/tools-pdf-to-image.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^compress-pdf/?$',
'index.php?compress_pdf=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='compress_pdf';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('compress_pdf')){

include get_template_directory().'/tools-compress-pdf.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^name-date-photo/?$',
'index.php?name_date_photo=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='name_date_photo';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('name_date_photo')){

include get_template_directory().'/tools-name-date-photo.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^crop-image/?$',
'index.php?crop_image=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='crop_image';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('crop_image')){

include get_template_directory().'/tools-crop-image.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^image-converter/?$',
'index.php?image_converter=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='image_converter';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('image_converter')){

include get_template_directory().'/tools-image-converter.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^reduce-image-size/?$',
'index.php?reduce_image_size=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='reduce_image_size';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('reduce_image_size')){

include get_template_directory().'/tools-reduce-image-size.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^merge-pdf/?$',
'index.php?merge_pdf=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='merge_pdf';

return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('merge_pdf')){

include get_template_directory().'/tools-merge-pdf.php';

exit;

}

});
add_action('init', function(){

add_rewrite_rule(
'^split-pdf/?$',
'index.php?split_pdf=1',
'top'
);

});

add_filter('query_vars', function($vars){

$vars[]='split_pdf';
return $vars;

});

add_action('template_redirect', function(){

if(get_query_var('split_pdf')){

include get_template_directory().'/tools-split-pdf.php';
exit;

}

});

/* Duplicate Post Button */
function rajnish_duplicate_post_as_draft(){
    global $wpdb;

    if (! ( isset($_GET['post']) || isset($_POST['post']) || ( isset($_REQUEST['action']) && 'rajnish_duplicate_post_as_draft' == $_REQUEST['action'] ) ) ) {
        wp_die('No post to duplicate has been supplied!');
    }

    $post_id = (isset($_GET['post']) ? absint($_GET['post']) : absint($_POST['post']));
    $post = get_post($post_id);

    if (isset($post) && $post != null) {

        $new_post = array(
            'post_title' => $post->post_title . ' (Copy)',
            'post_content' => $post->post_content,
            'post_status' => 'draft',
            'post_type' => $post->post_type,
            'post_author' => get_current_user_id()
        );

        $new_post_id = wp_insert_post($new_post);

        $taxonomies = get_object_taxonomies($post->post_type);
        foreach ($taxonomies as $taxonomy) {
            $post_terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
            wp_set_object_terms($new_post_id, $post_terms, $taxonomy, false);
        }

        $post_meta = get_post_meta($post_id);
        if ($post_meta) {
            foreach ($post_meta as $meta_key => $meta_values) {
                foreach ($meta_values as $meta_value) {
                    add_post_meta($new_post_id, $meta_key, $meta_value);
                }
            }
        }

        wp_redirect(admin_url('post.php?action=edit&post=' . $new_post_id));
        exit;
    } else {
        wp_die('Post creation failed.');
    }
}

add_action('admin_action_rajnish_duplicate_post_as_draft', 'rajnish_duplicate_post_as_draft');

function rajnish_duplicate_post_link($actions, $post) {
    if (current_user_can('edit_posts')) {
        $actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=rajnish_duplicate_post_as_draft&post=' . $post->ID, basename(__FILE__), 'duplicate_nonce' ) . '" title="Duplicate this item">Duplicate</a>';
    }
    return $actions;
}

add_filter('post_row_actions', 'rajnish_duplicate_post_link', 10, 2);