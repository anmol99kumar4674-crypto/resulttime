<?php get_header(); ?>

<div style="max-width:700px;margin:auto;text-align:center">

<h1>Split PDF</h1>

<input type="file" id="pdfFile" accept="application/pdf">

<br><br>

<button onclick="splitPDF()">Split PDF</button>

<br><br>

<div id="downloadLinks"></div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>

<script>

async function splitPDF(){

let file=document.getElementById("pdfFile").files[0];

let arrayBuffer=await file.arrayBuffer();

let pdf=await PDFLib.PDFDocument.load(arrayBuffer);

let totalPages=pdf.getPageCount();

let container=document.getElementById("downloadLinks");

container.innerHTML="";

for(let i=0;i<totalPages;i++){

let newPdf=await PDFLib.PDFDocument.create();

let [page]=await newPdf.copyPages(pdf,[i]);

newPdf.addPage(page);

let bytes=await newPdf.save();

let blob=new Blob([bytes],{type:"application/pdf"});

let url=URL.createObjectURL(blob);

let link=document.createElement("a");

link.href=url;
link.download="page-"+(i+1)+".pdf";
link.innerText="Download Page "+(i+1);

container.appendChild(link);
container.appendChild(document.createElement("br"));
container.appendChild(document.createElement("br"));

}

}

</script>

<?php get_footer(); ?>