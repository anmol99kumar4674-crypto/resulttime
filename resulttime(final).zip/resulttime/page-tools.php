<?php
/*
Template Name: Tools Page
*/
get_header();
?>

<style>

.tools-container{
max-width:1100px;
margin:auto;
padding:40px 20px;
}

.tools-title{
text-align:center;
font-size:32px;
font-weight:700;
margin:40px 0;
}

.tools-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
gap:25px;
padding:20px;
}

.tool-card{
display:block;
text-align:center;
background:#fff;
padding:30px 20px;
border-radius:12px;
box-shadow:0 4px 12px rgba(0,0,0,0.08);
text-decoration:none;
color:#333;
font-weight:600;
transition:0.3s;
}

.tool-card:hover{
transform:translateY(-6px);
box-shadow:0 10px 25px rgba(0,0,0,0.15);
}

.tool-icon{
font-size:35px;
margin-bottom:10px;
}

</style>
<div class="tools-title">Free Online Tools</div>

<div class="tools-grid">

<a href="/age-calculator" class="tool-card">
<div class="tool-icon">📅</div>
Age Calculator
</a>

<a href="/image-resizer" class="tool-card">
<div class="tool-icon">🖼️</div>
Image Resizer
</a>

<a href="/compress-image" class="tool-card">
<div class="tool-icon">📉</div>
Compress Image
</a>

<a href="/image-to-pdf" class="tool-card">
<div class="tool-icon">📄</div>
Image to PDF
</a>

<a href="/pdf-to-image" class="tool-card">
<div class="tool-icon">🖼️</div>
PDF to Image
</a>

<a href="/compress-pdf" class="tool-card">
<div class="tool-icon">📦</div>
Compress PDF
</a>

<a href="/name-date-photo" class="tool-card">
<div class="tool-icon">✏️</div>
Name & Date on Photo
</a>

<a href="/crop-image" class="tool-card">
<div class="tool-icon">📏</div>
Crop Image
</a>

<a href="/image-converter" class="tool-card">
<div class="tool-icon">🔄</div>
Image Converter
</a>

<a href="/reduce-image-size" class="tool-card">
<div class="tool-icon">⬇️</div>
Reduce Image Size
</a>

<a href="/merge-pdf" class="tool-card">
<div class="tool-icon">📑</div>
Merge PDF
</a>

<a href="/split-pdf" class="tool-card">
<div class="tool-icon">✂️</div>
Split PDF
</a>

</div>

<?php get_footer(); ?>